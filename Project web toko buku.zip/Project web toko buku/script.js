var selectedRow = null;

//show alert
function showAlert(message, className){
    const div = document.createElement("div");
    div.className = `alert alert-${className}`;

    div.appendChild(document.createTextNode(message));
    const container = document.querySelector(".container");
    const main = document.querySelector(".main");
    container.insertBefore(div, main);

    setTimeout(() => document.querySelector(".alert").remove(), 3000);
}

// clear all fields
function clearFields(){
    document.querySelector("judulBuku").value = "";
    document.querySelector("temaBuku").value = "";
    document.querySelector("hargaBuku").value = "";

}

// add data

document.querySelector("#student-form").addEventListener("submit",(e) =>{
e.preventDefault();

// get form values
const judulBuku = document.querySelector("#judulBuku").value;
const temaBuku = document.querySelector("#temaBuku").value;
const hargaBuku = document.querySelector("#hargaBuku").value;

// validate
if(judulBuku == "" || temaBuku == "" || hargaBuku == "" ){
    showAlert("please fill in all fields", "danger");
}
else{
    if(selectedRow == null){
        const list = document.querySelector("#student-list");
        const row = document.createElement("tr");
        
        row.innerHTML = `
        <td>${judulBuku}</td>
        <td>${temaBuku}</td>
        <td>${hargaBuku}</td>
        <td>
        <a href="#" class="btn btn-warning btn-sm edit">Edit</a>
        <a href="#" class="btn btn-danger btn-sm delete">Delete</a>
        `;
        list.appendChild(row);
        selectedRow = null;
        showAlert("student added", "success");
    }
    else {
        selectedRow.children[0].textContent = judulBuku;
        selectedRow.children[1].textContent = temaBuku;
        selectedRow.children[2].textContent = hargaBuku;
        selectedRow = null;
        showAlert("student info edited", "info")
    }
    clearFields();
}

});

//edit data
document.querySelector("#student-list").addEventListener("click", (e) =>{
    target = e.target;
    if(target.classList.contains("edit")){
        selectedRow = target.parentElement.parentElement;
        document.querySelector("#judulBuku").value = selectedRow.children[0].textContent;
        document.querySelector("#temaBuku").value = selectedRow.children[1].textContent;
        document.querySelector("#hargaBuku").value = selectedRow.children[2].textContent;

    }

});

//delete data

document.querySelector("#student-list").addEventListener("click", (e) => {
    target = e.target;
    if(target.classList.contains("delete")){
        target.parentElement.parentElement.remove();
        showAlert("student data deleted", "danger");
    }
});