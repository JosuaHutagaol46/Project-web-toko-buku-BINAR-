var selectedRow = null;

//show alert
function showAlert(message, className, image){
    const div = document.createElement("div");
    div.className = `alert alert-${className}`;

    div.appendChild(document.createTextNode(message));
    const container = document.querySelector(".container");
    const main = document.querySelector(".main");
    container.insertBefore(div, main);

    setTimeout(() => document.querySelector(".alert").remove(), 3000);
}

// clear all fields
function clearFields(){
    document.querySelector("ID").value = "";
    document.querySelector("judulBuku").value = "";
    document.querySelector("temaBuku").value = "";
    document.querySelector("hargaBuku").value = "";
    // Image.querySelector("gambarBuku").value = "";
    // Image.querySelector("") 
}

// add data

document.querySelector("#student-form").addEventListener("submit",(e) =>{
e.preventDefault();

// get form values
const ID = document.querySelector("#ID").value;
const judulBuku = document.querySelector("#judulBuku").value;
const temaBuku = document.querySelector("#temaBuku").value;
const hargaBuku = document.querySelector("#hargaBuku").value;
// const gambarBuku = Image.querySelector("gambarBuku").value;
input = document.querySelector("input");

input.addEventListener("change", () => {
    image.src = URL.createObjectURL(input.files[0]);
});
// validate
if(ID == "" || judulBuku == "" || temaBuku == "" || hargaBuku == "" || gambarBuku == ""){
    showAlert("please fill in all fields", "danger");
}
else{
    if(selectedRow == null){
        const list = document.querySelector("#student-list");
        const row = document.createElement("tr");
        
        
        row.innerHTML = `
        <td>${ID}</td>
        <td>${judulBuku}</td>
        <td>${temaBuku}</td>
        <td>${hargaBuku}</td>
        <td>${gambarBuku}</td>
        <td>
        <a href="#" class="btn btn-warning btn-sm edit">Edit</a>
        <a href="#" class="btn btn-danger btn-sm delete">Delete</a>
        `;
        list.appendChild(row);
        selectedRow = null;
        showAlert("Book added", "success");
    }
    else {
        selectedRow.children[0].textContent = ID;
        selectedRow.children[1].textContent = judulBuku;
        selectedRow.children[2].textContent = temaBuku;
        selectedRow.children[3].textContent = hargaBuku;
        // selectedRow.children[3].imageContent = gambarBuku;
        selectedRow = null;
        showAlert("Book info edited", "info")
    }
    clearFields();
}

});

//edit data
document.querySelector("#student-list").addEventListener("click", (e) =>{
    target = e.target;
    if(target.classList.contains("edit")){
        selectedRow = target.parentElement.parentElement;
        document.querySelector("#ID").value = selectedRow.children[0].textContent;
        document.querySelector("#judulBuku").value = selectedRow.children[1].textContent;
        document.querySelector("#temaBuku").value = selectedRow.children[2].textContent;
        document.querySelector("#hargaBuku").value = selectedRow.children[3].textContent;
        console.log(edit)
        // Image.querySelector("#gambarBuku").value = selectedRow.children[3].imageContent;

    }

});

//delete data

document.querySelector("#student-list").addEventListener("click", (e) => {
    target = e.target;
    if(target.classList.contains("delete")){
        target.parentElement.parentElement.remove();
        showAlert("Book data deleted", "danger");
    }
});

