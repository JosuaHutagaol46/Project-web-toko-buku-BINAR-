const express = require('express')
const bodyParser = require('body-parser')

const port = 8080
const client = require('./connection')
const app = express()

app.use(bodyParser.json())

app.listen(port, () => {
  console.log('app started on port ' + port)
})


client.connect(err =>{
    if(err){
        console.log(err.message)
    } else{
console.log('Connected')
    }
})

app.get('/Buku', (req,res) => {
    client.query(`Select * from Buku`,(result, err) => {
        if(!err){
            res.send(result.rows)
        }
    })
    
})

app.post('/Buku',(req,res) => {
const {Judul_buku, Tema_buku, Harga} = req.body

client.query((`insert into Buku (Judul_buku,Tema_buku,Harga) values ('${Judul_buku}','${Tema_buku}','${Harga}')`), (result,err)=>{
    if(!err){
        res.send('Insert Success')
    }
    else{
        res.send(err.message)
    }
})
})

app.put('/Buku/:ID',(req,res) => {
    const {Judul_buku, Tema_buku, Harga} = req.body
    client.query((`update Buku set Judul_buku = '${Judul_buku}',Tema_buku ='${Tema_buku}',Harga = '${Harga}',where id = ${req.params.ID}`), (result,err)=>{
        if(!err){
            res.send('Update Success')
        }
        else{
            res.send(err.message)
        }
    })
})


app.delete('/Buku/:ID',(req,res) => {
    client.query((`delete from Buku where id = ${req.params.ID}`,(result,err) => {
        if(!err){
            res.send('Delete Success')
        }
        else{
            res.send(err.message)
        }
    }))
})